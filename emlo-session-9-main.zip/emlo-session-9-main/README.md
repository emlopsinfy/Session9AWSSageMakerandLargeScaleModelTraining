# EMLO Session 9 Assignment
## Large Scale model training on AWS
--------------------------------------------
### Name: Akash Kumar
### Email: infiniteakashe@gmail.com
--------------------------------------------
### Name: Divyam Malay Shah
### Email: divyam096@gmail.com

This repo contains the relavent notebooks and code to train a ResNet model on CIFAR100 using multi-gpu multi-instance training jobs on SageMaker.
